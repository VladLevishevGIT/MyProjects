package a.create;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTables {

	public static void main(String[] args) {

		String url = "jdbc:derby://localhost:1527/coupon_system_db;create=true";
		String sql;

		try (Connection con = DriverManager.getConnection(url); Statement stmt = con.createStatement();) {

			sql = "CREATE TABLE company(id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), comp_name VARCHAR(30) UNIQUE, password VARCHAR(30), email VARCHAR(50))";
			stmt.executeUpdate(sql);
			sql = "CREATE TABLE customer(id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), cust_name VARCHAR(30) UNIQUE, password VARCHAR(30))";
			stmt.executeUpdate(sql);
			sql = "CREATE TABLE coupon(id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), title VARCHAR(30) UNIQUE, start_date DATE, end_date DATE, amount INT, type VARCHAR(20), message VARCHAR(50), price DOUBLE, image VARCHAR(50))";
			stmt.executeUpdate(sql);
			sql = "CREATE TABLE customer_coupon(cust_id BIGINT, coupon_id BIGINT, PRIMARY KEY (cust_id, coupon_id))";
			stmt.executeUpdate(sql);
			sql = "CREATE TABLE company_coupon(comp_id BIGINT, coupon_id BIGINT, PRIMARY KEY (comp_id, coupon_id))";
			stmt.executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
