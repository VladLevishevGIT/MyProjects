package a.drop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DropTables {

	public static void main(String[] args) {

		String url = "jdbc:derby://localhost:1527/coupon_system_db";
		String sql;

		try (Connection con = DriverManager.getConnection(url); Statement stmt = con.createStatement();) {

			sql = "DROP TABLE company";
			stmt.executeUpdate(sql);
			sql = "DROP TABLE customer";
			stmt.executeUpdate(sql);
			sql = "DROP TABLE coupon";
			stmt.executeUpdate(sql);
			sql = "DROP TABLE customer_coupon";
			stmt.executeUpdate(sql);
			sql = "DROP TABLE company_coupon";
			stmt.executeUpdate(sql);

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
