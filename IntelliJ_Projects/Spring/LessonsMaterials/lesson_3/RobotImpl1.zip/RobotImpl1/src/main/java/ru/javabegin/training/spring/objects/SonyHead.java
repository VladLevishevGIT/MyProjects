package ru.javabegin.training.spring.objects;

public class SonyHead {
	
	public void calc(){
		System.out.println("Thinking...");
	}

}
