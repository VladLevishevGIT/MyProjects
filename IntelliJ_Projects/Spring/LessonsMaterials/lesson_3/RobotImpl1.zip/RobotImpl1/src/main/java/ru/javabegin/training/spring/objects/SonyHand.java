package ru.javabegin.training.spring.objects;

public class SonyHand {
	
	public void catchSomething(){
		System.out.println("Catched!");
	}

}
