package ru.javabegin.training.spring.objects;

public class SonyLeg {
	
	public void go(){
		System.out.println("Go!");
	}

}
