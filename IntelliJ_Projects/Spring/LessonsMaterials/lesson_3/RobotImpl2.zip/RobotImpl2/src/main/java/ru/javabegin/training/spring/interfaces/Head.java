package ru.javabegin.training.spring.interfaces;

public interface Head {
	
	public void calc();
}
