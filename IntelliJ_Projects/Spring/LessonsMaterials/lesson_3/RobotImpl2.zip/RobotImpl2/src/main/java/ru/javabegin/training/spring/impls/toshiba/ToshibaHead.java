package ru.javabegin.training.spring.impls.toshiba;

import ru.javabegin.training.spring.interfaces.Head;

public class ToshibaHead implements Head{
	
	public void calc(){
		System.out.println("Thinking about Toshiba...");
	}

}
