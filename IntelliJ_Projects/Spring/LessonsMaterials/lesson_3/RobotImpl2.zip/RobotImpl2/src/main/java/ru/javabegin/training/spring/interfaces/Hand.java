package ru.javabegin.training.spring.interfaces;

public interface Hand {
	
	public void catchSomething();

}
