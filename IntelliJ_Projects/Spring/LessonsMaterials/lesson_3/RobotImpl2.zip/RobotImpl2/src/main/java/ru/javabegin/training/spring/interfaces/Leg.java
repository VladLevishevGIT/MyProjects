package ru.javabegin.training.spring.interfaces;

public interface Leg {
	
	public void go();

}
